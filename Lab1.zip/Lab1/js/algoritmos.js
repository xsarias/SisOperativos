// js/algoritmos.js

// ----------------------------
// FIRST FIT
// ----------------------------
export function firstFit(particiones, size) {
  for (let i = 0; i < particiones.length; i++) {
    const p = particiones[i];
    if (p.estado === "Libre" && p.size >= size) {
      return dividirParticion(particiones, i, size);
    }
  }
  return null; // No hay espacio suficiente
}

// ----------------------------
// BEST FIT
// ----------------------------
export function bestFit(particiones, size) {
  let mejor = -1;
  let menorDiferencia = Infinity;

  particiones.forEach((p, i) => {
    if (p.estado === "Libre" && p.size >= size) {
      const dif = p.size - size;
      if (dif < menorDiferencia) {
        menorDiferencia = dif;
        mejor = i;
      }
    }
  });

  return mejor !== -1 ? dividirParticion(particiones, mejor, size) : null;
}

// ----------------------------
// WORST FIT
// ----------------------------
export function worstFit(particiones, size) {
  let peor = -1;
  let mayorDiferencia = -1;

  particiones.forEach((p, i) => {
    if (p.estado === "Libre" && p.size >= size) {
      const dif = p.size - size;
      if (dif > mayorDiferencia) {
        mayorDiferencia = dif;
        peor = i;
      }
    }
  });

  return peor !== -1 ? dividirParticion(particiones, peor, size) : null;
}

// ----------------------------
// NEXT FIT
// ----------------------------
let lastIndex = 0;

export function nextFit(particiones, size) {
  const n = particiones.length;
  for (let i = 0; i < n; i++) {
    const idx = (lastIndex + i) % n;
    const p = particiones[idx];
    if (p.estado === "Libre" && p.size >= size) {
      lastIndex = idx; // actualiza posición del puntero
      return dividirParticion(particiones, idx, size);
    }
  }
  return null;
}

// ----------------------------
// FUNCION AUXILIAR: DIVIDIR PARTICIÓN
// ----------------------------
function dividirParticion(particiones, index, size) {
  const p = particiones[index];

  if (p.size === size) {
    return p; // Cabe justo, no hay división
  }

  // Crear nueva partición libre con el espacio restante
  const nuevaPart = {
    base: p.base + size,
    size: p.size - size,
    estado: "Libre",
    id: null
  };

  // Modificar la actual
  p.size = size;

  // Insertar la nueva justo después
  particiones.splice(index + 1, 0, nuevaPart);

  return p;
}
